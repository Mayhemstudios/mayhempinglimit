-------------------------------------------------+
-- ╭━┳━╮╱╱╱╱╭╮╱╱╱╱╱╱╭━━╮╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╭╮  |
-- ┃┃┃┃┣━╮╭┳┫╰┳━┳━━╮╰╮╮┣━┳━┳━┳━┳╮╭━┳━┳━━┳━┳━┳┫╰╮ |
-- ┃┃┃┃┃╋╰┫┃┃┃┃┻┫┃┃┃╭┻╯┃┻╋╮┃╭┫┻┫╰┫╋┃╋┃┃┃┃┻┫┃┃┃╭┫ |
-- ╰┻━┻┻━━╋╮┣┻┻━┻┻┻╯╰━━┻━╯╰━╯╰━┻━┻━┫╭┻┻┻┻━┻┻━┻━╯ |
-- ╱╱╱╱╱╱╱╰━╯╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╰╯	   	     | 
-------------------------------------------------+


pingLimit = 600 -- This is the Ping Limit. What ever this number is set to it will kick you if you pass that ping limit.


RegisterServerEvent("checkMyPingBro")
AddEventHandler("checkMyPingBro", function()
	ping = GetPlayerPing(source)
	if ping >= pingLimit then
		DropPlayer(source, "[Mayhem-PingLimit] You have been kicked for High Ping (Limit: " .. pingLimit .. " Your Ping: " .. ping .. ")")
	end
end)